"# Ecommerce" 

ADMIN PANEL LOGIN:

>> NOTE : (for admin panel, login from the user's login)
>>Enter the following details in Login for Admin Panel.

Username: admin@admin.com
Password: password

USER LOGIN:

Username: kapil@gmail.com
Password: kapil

DON'T FORGET TO CREATE A DATABASE NAMING "ecomm" AND IMPORT THE SQL FILE TO RUN.
WITHOUT THE DATABASE THE PROJECT WON'T RUN. If it Doesn't work download zip file.

>>DATABASE FILE IS INSIDE "database" FOLDER

*** IF YOU FIND ANY ERRORS OR ANY PROBLEMS RELATED THIS PROGRAM, FEEL FREE TO CONTACT US ***