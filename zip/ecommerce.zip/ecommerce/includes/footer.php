<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2019 Brought to You By <a href="#">HNP Security</a></strong>
    </div>
</footer>